
export default function Home() {
  return (
    <div>
      <div style={{ background: ""}} className=" ">
        <h2>
          Please go to <span className=" fw-bold">/authentication/login</span> this path
        </h2>
      </div>
    </div>
  );
}
